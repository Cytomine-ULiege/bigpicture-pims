from fsspec import register_implementation

from crypt4gh_fsspec.crypt4gh_filesystem import Crypt4GHFileSystem

register_implementation("crypt4gh", Crypt4GHFileSystem)
