import io
from pathlib import Path
from typing import Any, Dict, Optional, Union

from fsspec import AbstractFileSystem, filesystem
from nacl.public import PrivateKey, PublicKey

from crypt4gh_fsspec.crypt4gh_file import Crypt4GHFile, Crypt4GHMagic
from crypt4gh_fsspec.crypt4gh_keys import Crypt4GHKeys


class Crypt4GHFileSystem(AbstractFileSystem):
    def __init__(
        self,
        private_key: Union[PrivateKey, Path, str, bytes],
        sender_public_key: Optional[Union[PublicKey, Path, str, bytes]] = None,
        passthrough_plaintext: bool = True,
        path: Optional[str] = None,
        fs: Optional[AbstractFileSystem] = None,
        fo: Optional[Any] = None,
        target_protocol: Optional[str] = None,
        target_options: Optional[Dict[str, Any]] = None,
        **storage_options,
    ):
        if path is not None and fo is not None:
            raise ValueError("Provide path or fo, not both")
        super().__init__(self, **storage_options)
        self._keys = Crypt4GHKeys(private_key, sender_public_key)
        self._passthrough_plaintext = passthrough_plaintext
        if fs is None:
            self._fs = filesystem(protocol=target_protocol, **(target_options or {}))
        else:
            self._fs = fs

        path = path or fo
        if path is not None:
            self._path = self._fs._strip_protocol(path)
        else:
            self._path = None

    def _open(
        self,
        path: str,
        mode="rb",
        **kwargs,
    ) -> Union[io.IOBase, Crypt4GHFile]:
        file = self._fs._open(path, mode, **kwargs)
        if not Crypt4GHMagic(file).is_crypt4gh():
            if not self._passthrough_plaintext:
                raise ValueError(
                    "File is not crypt4gh and passthrough_plaintext is False"
                )
            return file
        if mode != "rb":
            raise ValueError("Only read binary ('rb') mode is supported")
        return Crypt4GHFile(self._fs, path, mode, self._keys, **kwargs)

    @property
    def fsid(self):
        return self._fs.fsid

    def cp_file(self, path1, path2, **kwargs):
        return self._fs.cp_file(path1, path2, **kwargs)

    def mkdir(self, path, create_parents=True, **kwargs):
        return self._fs.mkdir(path, create_parents, **kwargs)

    def makedirs(self, path, exist_ok=False):
        return self._fs.makedirs(path, exist_ok)

    def rmdir(self, path):
        return self._fs.rmdir(path)

    def _rm(self, path):
        return self._fs._rm(path)

    def touch(self, path, truncate=True, **kwargs):
        return self._fs.touch(path, truncate, **kwargs)

    def created(self, path):
        return self._fs.created(path)

    def modified(self, path):
        return self._fs.modified(path)

    def sign(self, path, expiration=100, **kwargs):
        return self._fs.sign(path, expiration, **kwargs)

    def ls(self, path, detail=True, **kwargs):
        return self._fs.ls(path, detail, **kwargs)
