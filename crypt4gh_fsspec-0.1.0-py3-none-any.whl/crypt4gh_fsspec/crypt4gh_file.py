import io
import math
from typing import Tuple, Union

from crypt4gh import header as crtyp4gh_header
from crypt4gh import lib as crypt4gh_lib
from crypt4gh.header import MAGIC_NUMBER
from crypt4gh.lib import CIPHER_DIFF, CIPHER_SEGMENT_SIZE, SEGMENT_SIZE
from fsspec import AbstractFileSystem
from fsspec.spec import AbstractBufferedFile

from crypt4gh_fsspec.crypt4gh_keys import Crypt4GHKeys


class Crypt4GHMagic:
    def __init__(
        self,
        file: Union[AbstractBufferedFile, io.IOBase],
    ):
        self._file = file

    def is_crypt4gh(self):
        self._file.seek(0)
        buffer = self._file.read(8)
        self._file.seek(0)
        return buffer == MAGIC_NUMBER


class Crypt4GHFile(AbstractBufferedFile):
    def __init__(
        self, fs: AbstractFileSystem, path: str, mode: str, keys: Crypt4GHKeys, **kwargs
    ) -> None:
        self._file = fs.open(path, mode)
        self.wrapped_file.seek(0)
        self._session_keys, edit_list = crtyp4gh_header.deconstruct(
            self.wrapped_file, [(0, keys.private_key, keys.sender_public_key)]
        )
        self._header_offset = self.wrapped_file.tell()
        size, segment_count = self._calculate_file_size_and_segment_count(
            self.wrapped_file.size, self._header_offset
        )
        self._segment_count = segment_count
        kwargs.pop("block_size", None)
        super().__init__(
            fs,
            path,
            block_size=SEGMENT_SIZE,  # type: ignore
            size=size,
            **kwargs,
        )

    @property
    def wrapped_file(self) -> AbstractBufferedFile:
        return self._file  # type: ignore

    @property
    def segment_count(self) -> int:
        return self._segment_count

    def read(self, length: int = -1):
        """
        Return data from cache, or fetch pieces as necessary.

        Override of parent method to ensure that we are not reading more than the file.

        Parameters
        ----------
        length: int = -1
            Number of bytes to read. Ff <0 all remaining bytes are read.
        """
        # Ensure that we are not reading more than the file length as some cache
        # implementations will raise if we do.
        if self.size - self.tell() < length:
            length = self.size - self.tell()
        return super().read(length)

    def _fetch_range(self, start: int, end: int) -> bytes:
        """Fetch decrypted data from the wrapped file.

        Start and end offsets must be aligned to the segment size.

        Parameters
        ----------
        start : int
            The start offset of the segment.
        end : int
            The end offset of the segment.

        Returns
        -------
        bytes
            The decrypted data.
        """
        if start % SEGMENT_SIZE == 0 and end - start == SEGMENT_SIZE == 0:
            return self._fetch_block(start, end)
        position = start
        with io.BytesIO() as output:
            while position < end:
                segment_index, segment_offset = self._offset_to_segment(position)
                ciphered_segment = self._read_segment(segment_index)
                decrypted_segment = self._decrypt_segment(ciphered_segment)
                part = decrypted_segment[
                    segment_offset : segment_offset + (end - position)
                ]
                if len(part) == 0:
                    break
                position += len(part)
                output.write(part)
            return output.getvalue()

    def _fetch_block(self, start: int, end: int) -> bytes:
        """Fetch a whole decrypted block from the wrapped file.

        Parameters
        ----------
        start : int
            The start offset of the segment.
        end : int
            The end offset of the segment.

        Returns
        -------
        bytes
            The decrypted data.
        """

        assert start % SEGMENT_SIZE == 0
        assert end - start == SEGMENT_SIZE
        segment_index, segment_offset = self._offset_to_segment(start)
        segment = self._read_segment(segment_index)
        if segment is None:
            return bytes()
        data = self._decrypt_segment(segment)
        return data

    def _read_segment(self, index: int) -> bytes:
        """Read a cipher segment from the file.

        Parameters
        ----------
        index : int
            The index of the cipher segment.

        Returns
        -------
        bytes
            The cipher segment.
        """
        if index >= self._segment_count:
            return bytes()
        segment_start = self._header_offset + index * CIPHER_SEGMENT_SIZE
        self.wrapped_file.seek(segment_start)
        data = self.wrapped_file.read(CIPHER_SEGMENT_SIZE)
        return data

    def _decrypt_segment(self, segment: bytes) -> bytes:
        """Decrypt a cipher segment.

        Parameters
        ----------
        segment : bytes
            The cipher segment.

        Returns
        -------
        bytes
            The decrypted segment.
        """
        return crypt4gh_lib.decrypt_block(segment, self._session_keys)

    @staticmethod
    def _offset_to_segment(offset: int) -> Tuple[int, int]:
        """Convert a byte offset to a segment index and segment offset.

        Parameters

        ----------
        offset : int
            The offset in bytes.

        Returns
        -------
        Tuple[int, int]
            The segment index and segment offset.
        """

        return divmod(offset, SEGMENT_SIZE)

    @staticmethod
    def _calculate_file_size_and_segment_count(
        encrypted_file_size: int, header_size: int
    ) -> Tuple[int, int]:
        """Calculate the size of the decrypted data and number of segments.

        The encrypted file starts with a header and is followed by a number of cipher
        segments. Each cipher segment is 28 bytes longer than the decrypted segment.

        Parameters
        ----------
        encrypted_file_size : int
            The size of the encrypted file.
        header_size : int
            The size of the header.

        Returns
        -------
        Tuple[int, int]
            The size of the decrypted data and number of segments.
        """
        cipher_segments_size = encrypted_file_size - header_size
        segment_count = math.ceil((cipher_segments_size) / CIPHER_SEGMENT_SIZE)
        return cipher_segments_size - segment_count * CIPHER_DIFF, segment_count

    def close(self):
        self.wrapped_file.close()
        super().close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        self.wrapped_file.__exit__(exc_type, exc_value, traceback)
