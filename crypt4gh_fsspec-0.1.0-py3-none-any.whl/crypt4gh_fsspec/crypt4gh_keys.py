from pathlib import Path
from typing import Optional, Union

from crypt4gh.keys import get_private_key, get_public_key
from nacl.public import PrivateKey, PublicKey


class Crypt4GHKeys:
    def __init__(
        self,
        private_key: Union[Path, str, bytes, PrivateKey],
        sender_public_key: Optional[Union[Path, str, bytes, PublicKey]] = None,
    ):
        if isinstance(private_key, (str, Path)):
            self._private_key = get_private_key(private_key, input)
        elif isinstance(private_key, PrivateKey):
            self._private_key = bytes(private_key)
        else:
            self._private_key = private_key
        if isinstance(sender_public_key, (str, Path)):
            self._sender_public_key = get_public_key(sender_public_key)
        elif isinstance(sender_public_key, PublicKey):
            self._sender_public_key = bytes(sender_public_key)
        else:
            self._sender_public_key = sender_public_key

    @property
    def private_key(self) -> bytes:
        return self._private_key

    @property
    def sender_public_key(self) -> Optional[bytes]:
        return self._sender_public_key
